# DigiBattle Deck Lab

Open APP/DigiBattle-DeckLab.html for the full portable app. For the installable
PWA and stable saved-workspace storage, follow APP/README.md.

The source is prepared for battle-simulation integration. It exports exact-input
preparation requests and shows actual engine readiness blockers. No unverified
battles or win rates are provided. See docs/ENGINE_HANDOFF.md for the next engine
work and request-validation command.

Source commit: 1f0ce95ff84252d1c426b07862f1794a2621a288
Automated tests passed: 211

This ZIP contains the complete current source, official source snapshots, built
apps and verification logs. Nested prior ZIPs are intentionally excluded. Complete
Git history remains on the GitHub general-browser-simulator branch. To initialize
a new local checkout from this extracted source, run git init and git add . before
committing; do not overwrite any existing engine-chat branch or worktree.
