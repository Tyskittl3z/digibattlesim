# DigiBattle Deck Lab — rebuilt November 2, 2026

Open APP/DigiBattle-DeckLab.html for the portable full-catalog app.
No installation or network requests are required. For reliable persistent
workspaces and installable offline PWA use APP/START-WINDOWS.cmd,
APP/START-MAC.command, or run `python APP/serve.py` (Python 3 required).

The app compares deck contents, checks pinned construction rules, saves local
workspaces and downloads exact-input reports. It does not play matches or
provide verified win rates.

All 194 automated tests passed. See REPORTS/BROWSER_RECOVERY_2026-11-02.md
and VERIFICATION/ for the checks, scope and remaining simulation blockers.

Branch: general-browser-simulator
Commit: 2a4180d2cf5738574a9b51d4bf0c06eec7b885d6

This ZIP contains full source, pinned official source HTML, generated app assets,
and HISTORY.bundle with complete reachable Git history. To resume from the bundle:

    git clone --branch general-browser-simulator HISTORY.bundle digibattlesim

Keep this ZIP outside the chat as a backup. The deleted chat's later commits were
not recovered; this is their browser/catalog scope reconstructed from screenshots.
