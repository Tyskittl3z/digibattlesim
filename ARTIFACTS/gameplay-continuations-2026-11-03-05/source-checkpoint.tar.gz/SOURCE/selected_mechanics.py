"""First selected EX13 mechanics; experimental scenarios, never full matches.

Exact orientation processing and four inherited reactions are implemented.
Persistent-status rule checks, Assembly, return-to-deck and other abilities
remain unsupported; all bindings are experimental and unreviewed.
An encountered dependency halts before the transaction commits.
"""
import hashlib
import json
from pathlib import Path
import re

from context_runtime import MechanicBinding, MechanicRegistry, OfficialEvidence, RuntimeHalt
from match_context import require
from effect_scheduler import queue_effects, source_stack
from printed_triggers import effect_body

ORIENTATION_EFFECT = 'EX13-023.orientation'
ORIENTATION_LINE = ('[On Play] [When Digivolving] [When Attacking] [Once Per Turn] '
                    '1 of your Digimon may change orientation.')
INHERITED_REACTIONS = {
    'EX13-022': ('EX13-022.inherited_unsuspend', '[All Turns] [Once Per Turn] When this Digimon with [Veedramon] in its name suspends, it may unsuspend.'),
    'BT22-023': ('BT22-023.inherited_unsuspend', '[All Turns] [Once Per Turn] When this Digimon with [Veedramon] in its name suspends, if you have a blue Tamer, this Digimon may unsuspend.'),
    'P-138': ('P-138.unsuspend_memory', '[Your Turn] [Once Per Turn] When this Digimon becomes unsuspended, gain 1 memory.'),
    'EX1-013': ('EX1-013.unsuspend_memory', '[Your Turn][Once Per Turn] When this Digimon becomes unsuspended during your main phase, gain 1 memory.'),
}
PHASE_EFFECTS = {
    'BT22-085': ('BT22-085.start_turn_memory','Start of Your Turn',
                 '[Start of Your Turn] If you have 2 or less memory, set it to 3.'),
    'BT19-080': ('BT19-080.start_turn_memory','Start of Your Turn',
                 '[Start of Your Turn] If you have 2 or less memory, set it to 3.'),
    'BT19-007': ('BT19-007.start_main_memory','Start of Your Main Phase',
                 '[Start of Your Main Phase] If you have [Takato Matsuki] or [Calumon], gain 1 memory.'),
    'EX13-069': ('EX13-069.start_main_memory','Start of Your Main Phase',
                 '[Start of Your Main Phase] If you have a Digimon with [Veemon] or [Veedramon] in its name, gain 1 memory.'),
}


def orientation_candidates(runtime, seat, source_key):
    source = runtime._source(seat, source_key, 'main_text')
    if source.card_number != 'EX13-023':
        raise RuntimeHalt('ORIENTATION_SOURCE_MISMATCH')
    return [None] + sorted(key for key, stack in runtime.state.battle[seat].items()
                          if runtime.context.card(seat, stack.cards[-1].card_number).kind == 'Digimon')


def _orientation_dependencies(runtime):
    # Conservative scope barrier, not a claim that each matching effect triggers
    # in this position. Until timing/conditions are implemented, retain the
    # precise source rather than silently suppress a potentially live reaction.
    reaction = re.compile(r'\bwhen\b[^\n]*\b(?:unsuspend|unsuspends|suspend|suspends|suspended|unsuspended)\b', re.I)
    for seat in ('A', 'B'):
        for stack in runtime.state.battle[seat].values():
            for index, card in enumerate(stack.cards):
                field_ = 'main_text' if index == len(stack.cards) - 1 else 'inherited_text'
                text = runtime.context.card(seat, card.card_number).effect_text(field_)
                if any(reaction.search(effect_body(line)) for line in text.splitlines()):
                    known = INHERITED_REACTIONS.get(card.card_number)
                    if field_ == 'inherited_text' and known and text == known[1]:
                        runtime.registry.lookup(card.card_number,known[0],field_)
                        continue
                    raise RuntimeHalt('ORIENTATION_DEPENDENT_TRIGGER_UNIMPLEMENTED: '
                                      + card.card_number + ' ' + field_)
            if set(stack.statuses) - {'cannot_suspend', 'cannot_unsuspend','effect_grants'}:
                # Includes DP reduction: EX13-023 Q7269 says a 0-DP rule check
                # precedes triggered effects; an unsuspend cannot rescue it.
                raise RuntimeHalt('ORIENTATION_STATUS_UNSUPPORTED: ' + stack.cards[-1].key)
            if 'effect_grants' in stack.statuses:
                from effect_grants import validate_grants
                validate_grants(runtime,seat,stack.cards[-1].key)
            if any(type(v) is not bool for k,v in stack.statuses.items() if k!='effect_grants'):
                raise RuntimeHalt('ORIENTATION_STATUS_UNSUPPORTED: non-boolean prohibition')


def _usage(runtime,seat,source,effect):
    return (runtime.state.turn,seat,source,effect)


def _orientation_reactions(runtime,seat,stack,suspended_before):
    if suspended_before == stack.suspended:
        return
    top = stack.cards[-1]
    definition = runtime.context.card(seat,top.card_number).to_dict()
    effects = []
    for card in stack.cards[:-1]:
        known = INHERITED_REACTIONS.get(card.card_number)
        if not known:
            continue
        is_unsuspend = card.card_number in ('P-138','EX1-013')
        if is_unsuspend:
            applies = suspended_before and not stack.suspended and runtime.state.active == seat
            if card.card_number == 'EX1-013':
                applies = applies and runtime.state.phase == 'MAIN'
        else:
            applies = not suspended_before and stack.suspended and 'Veedramon' in definition['name']
        if applies:
            effects.append({'seat':seat,'source':card.key,'effect_id':known[0],'field':'inherited_text',
                            'usage':list(_usage(runtime,seat,card.key,known[0])),
                            'trigger':{'kind':'ORIENTATION_CHANGED','entity':top.key,
                                       'suspended_before':suspended_before,'suspended_after':stack.suspended,
                                       'name_at_trigger':definition['name'],'phase':runtime.state.phase}})
    queue_effects(runtime,effects)


def _set_orientation(runtime,seat,stack,suspended):
    before = stack.suspended
    prohibition = 'cannot_suspend' if suspended else 'cannot_unsuspend'
    from effect_grants import active_restriction
    blocked = before != suspended and (stack.statuses.get(prohibition,False)
        or ('effect_grants' in stack.statuses
            and active_restriction(runtime,seat,stack.cards[-1].key,prohibition)))
    if before != suspended and not blocked:
        _orientation_dependencies(runtime)
        stack.suspended = suspended
        _orientation_reactions(runtime,seat,stack,before)
    return {'suspended_before':before,'suspended_after':stack.suspended,
            'changed':before != stack.suspended,'prohibition':prohibition if blocked else None}


def resolve_orientation(runtime, seat, source_key, target):
    """Resolve an already activated effect in a closed, verified-scope scenario.

    target=None declines optional processing AFTER activation, consuming OPT
    under comprehensive rule 15-14-1-4. This is distinct from declining to
    activate a pending effect; no automatic decline or learning occurs here.
    """
    if target not in orientation_candidates(runtime, seat, source_key):
        raise RuntimeHalt('ORIENTATION_TARGET_INVALID')
    usage = (runtime.state.turn, seat, source_key, ORIENTATION_EFFECT)
    if usage in runtime.state.once_used:
        raise RuntimeHalt('ONCE_PER_TURN_ALREADY_USED: ' + source_key)
    if target is None:
        runtime.state.once_used.add(usage)
        return {'changed': False, 'processing': 'OPTIONAL_PROCESSING_DECLINED_AFTER_ACTIVATION',
                'once_per_turn_consumed': True}
    stack = runtime.state.battle[seat][target]
    runtime.state.once_used.add(usage)
    result = _set_orientation(runtime,seat,stack,not stack.suspended)
    return {'target':target,**result,'once_per_turn_consumed':True}


def resolve_inherited_unsuspend(runtime,seat,source,choice):
    if type(choice) is not bool:
        raise RuntimeHalt('BOOLEAN_PROCESSING_CHOICE_REQUIRED')
    physical = runtime._source(seat,source,'inherited_text')
    known = INHERITED_REACTIONS.get(physical.card_number)
    if physical.card_number not in ('EX13-022','BT22-023') or known is None:
        raise RuntimeHalt('INHERITED_UNSUSPEND_SOURCE_INVALID')
    usage = _usage(runtime,seat,source,known[0])
    if usage in runtime.state.once_used:
        raise RuntimeHalt('ONCE_PER_TURN_ALREADY_USED')
    runtime.state.once_used.add(usage)
    if not choice:
        return {'changed':False,'processing':'OPTIONAL_PROCESSING_DECLINED_AFTER_ACTIVATION'}
    if physical.card_number == 'BT22-023':
        blue = any(runtime.context.card(seat,s.cards[-1].card_number).kind=='Tamer'
                   and 'Blue' in runtime.context.card(seat,s.cards[-1].card_number).to_dict()['colors']
                   for s in runtime.state.battle[seat].values())
        if not blue:
            return {'changed':False,'processing':'BLUE_TAMER_CONDITION_FAILED'}
    stack = source_stack(runtime,seat,source,'inherited_text')
    return {**_set_orientation(runtime,seat,stack,False),'processing':'OPTIONAL_UNSUSPEND_SELECTED'}


def resolve_unsuspend_memory(runtime,seat,source,choice):
    physical = runtime._source(seat,source,'inherited_text')
    if physical.card_number not in ('P-138','EX1-013') or choice is not None:
        raise RuntimeHalt('MEMORY_REACTION_SOURCE_OR_CHOICE_INVALID')
    if runtime.state.active != seat or (physical.card_number == 'EX1-013' and runtime.state.phase!='MAIN'):
        raise RuntimeHalt('MEMORY_TRIGGER_NOT_APPLICABLE')
    effect = INHERITED_REACTIONS[physical.card_number][0]
    usage = _usage(runtime,seat,source,effect)
    if usage in runtime.state.once_used:
        raise RuntimeHalt('ONCE_PER_TURN_ALREADY_USED')
    runtime.state.once_used.add(usage)
    before = runtime.state.memory
    runtime.state.memory = min(10,before+1)
    return {'memory_before':before,'memory_after':runtime.state.memory,'gained':runtime.state.memory-before}


def resolve_phase_memory(runtime,seat,source,choice):
    physical = runtime._source(seat,source,'main_text')
    spec = PHASE_EFFECTS.get(physical.card_number)
    if spec is None or choice is not None or runtime.state.active!=seat:
        raise RuntimeHalt('PHASE_MEMORY_SOURCE_OR_CHOICE_INVALID')
    expected_phase = 'TURN_START_EFFECTS' if spec[1]=='Start of Your Turn' else 'MAIN'
    if runtime.state.phase!=expected_phase:
        raise RuntimeHalt('PHASE_MEMORY_TIMING_INVALID')
    before = runtime.state.memory
    condition = True
    if physical.card_number in ('BT22-085','BT19-080'):
        condition = before<=2
        if condition:runtime.state.memory=3
    elif physical.card_number=='BT19-007':
        condition = any(runtime.context.card(seat,s.cards[-1].card_number).name in ('Takato Matsuki','Calumon')
                        for s in runtime.state.battle[seat].values())
        if condition:runtime.state.memory=min(10,before+1)
    elif physical.card_number=='EX13-069':
        condition = any(runtime.context.card(seat,s.cards[-1].card_number).kind=='Digimon'
                        and any(name in runtime.context.card(seat,s.cards[-1].card_number).name
                                for name in ('Veemon','Veedramon')) for s in runtime.state.battle[seat].values())
        if condition:runtime.state.memory=min(10,before+1)
    return {'memory_before':before,'memory_after':runtime.state.memory,'condition_met':condition}


def _source_evidence(root, source, locator):
    root = Path(root).resolve()
    base = (root / 'RULES').resolve()
    path = (root / source['file']).resolve()
    require(path.is_relative_to(base) and base.is_relative_to(root), 'Official source escapes RULES')
    return OfficialEvidence.from_bytes(source['url'], path.read_bytes(), source['sha256'], locator)


def build_selected_registry(context, root):
    cards = {c.number: c for c in context.cards}
    index = json.loads((Path(root) / 'RULES/matchups/123129-vs-124303/SOURCE_INDEX.json').read_bytes())
    source = next(d for d in index['sources'] if d['id'] == 'rules')
    rules = _source_evidence(root,source,'Comprehensive rules v4.3: 4-13; 15-3; 15-4; 15-14-1; memory cap 1-4-2')
    specs = [('EX13-023',ORIENTATION_EFFECT,'main_text',ORIENTATION_LINE,resolve_orientation)] + [
        (number,effect,'inherited_text',line,
         resolve_inherited_unsuspend if number in ('EX13-022','BT22-023') else resolve_unsuspend_memory)
        for number,(effect,line) in INHERITED_REACTIONS.items()] + [
        (number,effect,'main_text',line,resolve_phase_memory)
        for number,(effect,timing,line) in PHASE_EFFECTS.items()]
    bindings = []
    for number,effect,field,line,handler in specs:
        if number not in cards:
            continue
        card = cards[number]
        require(line in card.effect_text(field).splitlines(),'Exact mechanic text changed: '+number)
        evidence = (_source_evidence(root,card.to_dict()['official_source'],
                                    '#'+number+' '+field+'; EX1-013 Q3203 / EX13-023 Q7266-Q7269 where applicable'),rules)
        bindings.append(MechanicBinding(number,effect,field,card.definition_sha256,
                                       hashlib.sha256(card.effect_text(field).encode()).hexdigest(),evidence,handler))
    from search_effects import search_bindings
    bindings.extend(search_bindings(context,root,rules))
    from on_play_effects import on_play_bindings
    bindings.extend(on_play_bindings(context,root,rules))
    from option_actions import option_bindings
    bindings.extend(option_bindings(context,root,rules))
    from aero_effects import aero_bindings
    bindings.extend(aero_bindings(context,root,rules))
    from tamer_play_effects import tamer_play_bindings
    bindings.extend(tamer_play_bindings(context,root,rules))
    from security_tamer import security_tamer_bindings
    bindings.extend(security_tamer_bindings(context,root,rules))
    return MechanicRegistry(tuple(bindings))
